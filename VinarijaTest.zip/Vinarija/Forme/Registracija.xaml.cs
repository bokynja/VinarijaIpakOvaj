﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFRegistracija.Forme
{
    /// <summary>
    /// Interaction logic for FrmRegistracija.xaml
    /// </summary>
    public partial class FrmRegistracija : Window
    {
        SqlConnection konekcija = new SqlConnection();
        Konekcija kon = new Konekcija();
        public FrmRegistracija()
        {
            InitializeComponent();
            konekcija = kon.KreirajKonekciju();
            PopuniPadajuceListe();
            txtBrojTablice.Focus();
        }

        private void PopuniPadajuceListe()
        {
            try
            {
                konekcija.Open();

                string vratiVozila = @"Select VoziloID, BrojSasije from tblVozilo";
                DataTable dtVozila = new DataTable();
                SqlDataAdapter daVozila = new SqlDataAdapter(vratiVozila, konekcija);
                daVozila.Fill(dtVozila);
                cbVozilo.ItemsSource = dtVozila.DefaultView;
                dtVozila.Dispose();
                daVozila.Dispose();
            }
            catch (SqlException)
            {
                MessageBox.Show("Padajuće liste nisu popunjene!", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                if (konekcija != null)
                    konekcija.Close();
            }

        }

    }
}
